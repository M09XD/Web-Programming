CREATE DATABASE IF NOT EXISTS sundarban;
USE sundarban;
DROP TABLE IF EXISTS sales_data;
CREATE TABLE sales_data (
    SaleID INT PRIMARY KEY,
    ProductName VARCHAR(50) NOT NULL,
    CategoryID INT NOT NULL,
    CategoryName VARCHAR(50) NOT NULL,
    Quantity INT NOT NULL,
    Revenue DECIMAL(12,2) NOT NULL
);
INSERT INTO sales_data VALUES
(1,'Laptop',301,'Electronics',5,350000),
(2,'Mouse',301,'Electronics',15,45000),
(3,'Chair',302,'Furniture',8,64000),
(4,'Desk',302,'Furniture',6,72000),
(5,'Bottle',303,'Accessories',20,30000),
(6,'Pen',303,'Accessories',25,20000);
