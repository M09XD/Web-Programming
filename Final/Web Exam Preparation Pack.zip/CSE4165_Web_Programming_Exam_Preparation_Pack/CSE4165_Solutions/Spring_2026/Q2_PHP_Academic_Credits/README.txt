Spring_2026/Q2_PHP_Academic_Credits
Files in this folder answer one past-paper question.
For PHP/MySQL questions: import setup.sql in phpMyAdmin first, then open the PHP file through http://localhost/.
For JavaScript questions: open index.html in a browser.
Code is intentionally kept close to the beginner Lab 6-11 style.
